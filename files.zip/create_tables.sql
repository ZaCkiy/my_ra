-- url= (local file)
-- Create tables for Room Attendant app

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE shifts (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  date date NOT NULL,
  started_at timestamptz DEFAULT now(),
  ended_at timestamptz,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE rooms (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  shift_id uuid REFERENCES shifts(id) ON DELETE CASCADE,
  room_number text NOT NULL,
  status_1 text NOT NULL,
  status_2 text,
  status_3 text,
  time_in timestamptz,
  time_out timestamptz,
  towels integer DEFAULT 0,
  bath_towels integer DEFAULT 0,
  linen integer DEFAULT 0,
  amenities integer DEFAULT 0,
  credit integer DEFAULT 1,
  completed boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE room_events (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  room_id uuid REFERENCES rooms(id) ON DELETE CASCADE,
  event_type text NOT NULL, -- e.g., "time_in","time_out","status_change","amenities_change","end"
  payload jsonb,
  device_time timestamptz,
  server_time timestamptz DEFAULT now()
);

CREATE INDEX idx_rooms_shift ON rooms(shift_id);
CREATE INDEX idx_room_events_room ON room_events(room_id);