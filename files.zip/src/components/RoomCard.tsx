import React from "react";

type Room = {
  id: string;
  room_number: string;
  status_1: string;
  status_2?: string;
  status_3?: string;
  time_in?: string;
  time_out?: string;
  completed: boolean;
};

export default function RoomCard({ room, onOpen }: { room: Room; onOpen: (id: string) => void; }) {
  return (
    <div className={`p-4 rounded-md shadow-sm ${room.completed ? 'bg-gray-100' : 'bg-white'}`}>
      <div className="flex items-center justify-between">
        <div>
          <div className="text-xl font-semibold">{room.room_number}</div>
          <div className="flex gap-2 mt-1">
            <span className="px-2 py-1 bg-blue-100 rounded text-sm">{room.status_1}</span>
            {room.status_2 && <span className="px-2 py-1 bg-gray-100 rounded text-sm">{room.status_2}</span>}
            {room.status_3 && <span className="px-2 py-1 bg-gray-100 rounded text-sm">{room.status_3}</span>}
          </div>
        </div>
        <button className="btn-primary" onClick={() => onOpen(room.id)}>{room.completed ? 'Lihat' : 'Buka'}</button>
      </div>
      <div className="mt-2 text-sm text-gray-600">
        {room.time_in ? `In: ${new Date(room.time_in).toLocaleTimeString()}` : 'Belum Time In'}
        {' • '}
        {room.time_out ? `Out: ${new Date(room.time_out).toLocaleTimeString()}` : ''}
      </div>
    </div>
  );
}